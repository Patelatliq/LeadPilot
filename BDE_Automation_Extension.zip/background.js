chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'saveLead') {
        handleSaveLead(request.data, sendResponse);
        return true; // Indicates async response
    }
});

function handleSaveLead(data, sendResponse) {
    chrome.storage.sync.get(['sheetId'], (result) => {
        const sheetId = result.sheetId;
        if (!sheetId) {
            console.error('No Sheet ID found');
            sendResponse({ success: false, error: 'No Sheet ID configuration' });
            return;
        }

        chrome.identity.getAuthToken({ interactive: false }, (token) => {
            if (chrome.runtime.lastError || !token) {
                console.error('Auth Error', chrome.runtime.lastError);
                sendResponse({ success: false, error: 'Auth failed' });
                return;
            }

            appendRowToSheet(sheetId, token, data)
                .then(() => sendResponse({ success: true }))
                .catch((err) => {
                    console.error('Sheet API Error', err);
                    sendResponse({ success: false, error: err.message });
                });
        });
    });
}

async function appendRowToSheet(sheetId, token, data) {
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/A1:append?valueInputOption=USER_ENTERED`;

    const values = [
        [
            data.name,
            data.headline,
            data.company,
            data.url,
            'New', // Status
            new Date().toLocaleDateString() // Date
        ]
    ];

    const response = await fetch(url, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ values })
    });

    if (!response.ok) {
        const text = await response.text();
        throw new Error('Sheet API returned ' + response.status + ': ' + text);
    }
}
