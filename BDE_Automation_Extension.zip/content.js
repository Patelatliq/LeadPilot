console.log('BDE Automation Content Script Loaded');

// --- Configuration & Selectors ---
const SELECTORS = {
    name: [
        'h1.text-heading-xlarge',
        '.ph5 h1',
        '.artdeco-entity-lockup__title', // common in lists
        'h1' // absolute fallback
    ],
    headline: [
        '.text-body-medium.break-words',
        '.artdeco-entity-lockup__subtitle'
    ],
    company: [
        '.pv-text-details__right-panel div[aria-label]', // Company often in right panel
        '.artdeco-entity-lockup__subtitle', // Sometimes combined
        'ul.pv-text-details__right-panel li button'
    ],
    salesNav: {
        name: '[data-anonymize="person-name"]',
        company: '[data-anonymize="company-name"]',
        headline: '[data-anonymize="job-title"]'
    }
};

// --- Main Injection Logic ---
function injectButtons() {
    if (document.getElementById('bde-automation-float')) return;

    const floatBtn = document.createElement('div');
    floatBtn.id = 'bde-automation-float';
    floatBtn.innerHTML = `
    <div class="bde-header">BDE Tools</div>
    <div class="bde-controls">
      <button id="bde-save-lead">💾 Save Lead</button>
      <button id="bde-connect">👋 Connect</button>
      <button id="bde-message">💬 Message</button>
    </div>
    <div id="bde-status"></div>
  `;
    document.body.appendChild(floatBtn);

    document.getElementById('bde-save-lead').addEventListener('click', parseProfileAndSave);
    document.getElementById('bde-connect').addEventListener('click', handleConnect);
    document.getElementById('bde-message').addEventListener('click', handleMessage);
}

// --- Data Extraction Logic ---
function getElementText(selectorList, context = document) {
    for (const selector of selectorList) {
        const el = context.querySelector(selector);
        if (el && el.innerText.trim()) {
            return el.innerText.trim();
        }
    }
    return null;
}

function extractLeadData() {
    const url = window.location.href;
    let name, headline, company;

    // 1. Try Sales Navigator Specific Selectors (if on Sales Nav)
    if (url.includes('sales')) {
        name = getElementText([SELECTORS.salesNav.name]);
        headline = getElementText([SELECTORS.salesNav.headline]);
        company = getElementText([SELECTORS.salesNav.company]);
    }

    // 2. Try Standard LinkedIn Profile Selectors
    if (!name) name = getElementText(SELECTORS.name);
    if (!headline) headline = getElementText(SELECTORS.headline);
    if (!company) company = getElementText(SELECTORS.company);

    // 3. Fallback: Meta tags
    if (!name) {
        const title = document.title; // usually "Name - Headline | LinkedIn"
        if (title.includes('|')) {
            name = title.split('|')[0].split('-')[0].trim();
        }
    }

    return {
        name: name || 'Unknown Name',
        headline: headline || 'Unknown Headline',
        company: company || 'Unknown Company',
        url: url,
        timestamp: new Date().toISOString()
    };
}

function parseProfileAndSave() {
    updateStatus('Extracting...', 'blue');
    const leadData = extractLeadData();
    console.log('Extracted Lead Data:', leadData);

    if (leadData.name === 'Unknown Name') {
        if (!confirm('Could not detect name. Save anyway?')) return;
    }

    chrome.runtime.sendMessage({ action: 'saveLead', data: leadData }, (response) => {
        if (chrome.runtime.lastError) {
            updateStatus('Error: ' + chrome.runtime.lastError.message, 'red');
            return;
        }

        if (response && response.success) {
            updateStatus('Saved to Sheet! ✅', 'green');
        } else {
            updateStatus('Failed: ' + (response?.error || 'Unknown error'), 'red');
        }
    });
}

function handleConnect() {
    chrome.storage.sync.get(['connectTemplate'], (result) => {
        const template = result.connectTemplate || "Hi [Name], I'd like to connect.";
        const lead = extractLeadData();
        const filledTemplate = template.replace('[Name]', lead.name.split(' ')[0]);

        navigator.clipboard.writeText(filledTemplate).then(() => {
            updateStatus('Template copied! 📋', 'green');
            // Optional: Try to auto-click connect button if we can find it
            // const connectBtn = document.querySelector('button[aria-label*="Invite"]');
            // if (connectBtn) connectBtn.click();
        });
    });
}

function handleMessage() {
    chrome.storage.sync.get(['messageTemplate'], (result) => {
        const template = result.messageTemplate || "Hi [Name], ...";
        const lead = extractLeadData();
        const filledTemplate = template.replace('[Name]', lead.name.split(' ')[0]);

        navigator.clipboard.writeText(filledTemplate).then(() => {
            updateStatus('Message copied! 📋', 'green');
        });
    });
}

function updateStatus(msg, color = 'black') {
    const el = document.getElementById('bde-status');
    if (el) {
        el.style.color = color;
        el.innerText = msg;
        setTimeout(() => { el.innerText = ''; }, 3000);
    }
}

// Run injection periodically via MutationObserver is better, but interval is safer for simple scripts
setInterval(injectButtons, 1000);
