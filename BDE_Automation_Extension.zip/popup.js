document.addEventListener('DOMContentLoaded', () => {
  const sheetIdInput = document.getElementById('sheetId');
  const saveSheetIdBtn = document.getElementById('saveSheetId');
  const connectTemplateInput = document.getElementById('connectTemplate');
  const saveConnectTemplateBtn = document.getElementById('saveConnectTemplate');
  const messageTemplateInput = document.getElementById('messageTemplate');
  const saveMessageTemplateBtn = document.getElementById('saveMessageTemplate');
  const authorizeBtn = document.getElementById('authorizeBtn');
  const statusDiv = document.getElementById('status');

  // Load saved settings
  chrome.storage.sync.get(['sheetId', 'connectTemplate', 'messageTemplate'], (result) => {
    if (result.sheetId) sheetIdInput.value = result.sheetId;
    if (result.connectTemplate) connectTemplateInput.value = result.connectTemplate;
    if (result.messageTemplate) messageTemplateInput.value = result.messageTemplate;
  });

  saveSheetIdBtn.addEventListener('click', () => {
    chrome.storage.sync.set({ sheetId: sheetIdInput.value }, () => {
      showStatus('Sheet ID saved!');
    });
  });

  saveConnectTemplateBtn.addEventListener('click', () => {
    chrome.storage.sync.set({ connectTemplate: connectTemplateInput.value }, () => {
      showStatus('Connect template saved!');
    });
  });

  saveMessageTemplateBtn.addEventListener('click', () => {
    chrome.storage.sync.set({ messageTemplate: messageTemplateInput.value }, () => {
      showStatus('Message template saved!');
    });
  });

  authorizeBtn.addEventListener('click', () => {
    chrome.identity.getAuthToken({ interactive: true }, (token) => {
      if (chrome.runtime.lastError) {
        showStatus('Error: ' + chrome.runtime.lastError.message);
      } else {
        showStatus('Authorized successfully!');
        console.log('Token:', token);
      }
    });
  });

  function showStatus(msg) {
    statusDiv.textContent = msg;
    setTimeout(() => {
      statusDiv.textContent = '';
    }, 3000);
  }
});
